const ExcelJS = require("exceljs");
const path = require("path");
const fs = require("fs");

class ExcelService {
  async generateScheduleExcel(scheduleData, departmentName) {
    const templatePath = path.resolve(
      "c:/Users/ibrah/Downloads/BOŞ BÜTÜNLEŞİK ŞABLON - yazlab (1).xlsx"
    );

    // Şablon dosyasını kontrol et
    if (!fs.existsSync(templatePath)) {
      console.error("Şablon dosyası bulunamadı:", templatePath);
      throw new Error("Şablon dosyası bulunamadı.");
    }

    const workbook = new ExcelJS.Workbook();
    await workbook.xlsx.readFile(templatePath);

    const worksheet = workbook.getWorksheet(1);

    // Gün ve saat haritaları
    const dayRows = {
      Pazartesi: 4,
      Salı: 14,
      Çarşamba: 23,
      Perşembe: 28,
      Cuma: 36,
    };

    const classColumns = {
      "1. Sınıf": "C",
      "2. Sınıf": "D",
      "3. Sınıf": "E",
      "4. Sınıf": "F",
    };

    // Bölüm adını yaz
    this.writeDepartmentName(worksheet, "C1", departmentName);

    if (!scheduleData || Object.keys(scheduleData).length === 0) {
      throw new Error("scheduleData boş veya hatalı.");
    }

    // Her sınıf için programı yaz
    for (const [className, days] of Object.entries(scheduleData)) {
      for (const [day, hours] of Object.entries(days)) {
        const startRow = dayRows[day];
        if (!startRow) continue;

        for (const [hour, lesson] of Object.entries(hours)) {
          const rowOffset = this.getRowOffsetForTime(hour);
          const currentRow = startRow + rowOffset;

          const column = classColumns[className];
          if (!column || !lesson) continue;

          const cell = worksheet.getCell(`${column}${currentRow}`);
          cell.value = `${lesson.courseName}\n${lesson.instructor}\n${lesson.classroom}`;
          cell.alignment = {
            vertical: "middle",
            horizontal: "center",
            wrapText: true,
          }; // Hücreyi ortala ve metni sar
          console.log(
            `Yazılan hücre: ${column}${currentRow}, Değer: ${lesson.courseName}`
          );
        }
      }
    }

    // Yeni dosyayı kaydet
    const filePath = `ders_programi_${departmentName}.xlsx`;
    await workbook.xlsx.writeFile(filePath);
    console.log("Dosya başarıyla kaydedildi:", filePath);
    return filePath;
  }

  // Bölüm adını yazan yardımcı fonksiyon
  writeDepartmentName(worksheet, cellAddress, departmentName) {
    const cell = worksheet.getCell(cellAddress);
    cell.value = departmentName;
    cell.font = { bold: true, size: 14 }; // Yazı tipi ayarları
    cell.alignment = { vertical: "middle", horizontal: "center" }; // Hücreyi ortala
  }

  // Saat için satır offset'ini döndüren yardımcı fonksiyon
  getRowOffsetForTime(time) {
    const timeMap = {
      "09:00-10:00": 0,
      "10:00-11:00": 1,
      "11:00-12:00": 2,
      "13:00-14:00": 3,
      "14:00-15:00": 4,
      "15:00-16:00": 5,
      "16:00-17:00": 6,
    };
    return timeMap[time] || 0;
  }

  async readScheduleForTeacher(filePath, teacherName) {
    const workbook = new ExcelJS.Workbook();
    await workbook.xlsx.readFile(filePath);

    const worksheet = workbook.getWorksheet(1); // İlk sayfa
    const schedule = [];

    worksheet.eachRow((row, rowNumber) => {
      const [day, time, courseName, instructor] = row.values.slice(1); // Hücre değerlerini al
      if (instructor === teacherName) {
        schedule.push({ day, time, courseName, instructor });
      }
    });

    return schedule;
  }
  // Bölüm ve sınıfın ders programını oku
  async readScheduleForClass(filePath, department, grade) {
    const workbook = new ExcelJS.Workbook();
    await workbook.xlsx.readFile(filePath);

    const worksheet = workbook.getWorksheet(1); // İlk sayfa
    const schedule = [];

    worksheet.eachRow((row, rowNumber) => {
      const [day, time, courseName, instructor, classInfo] =
        row.values.slice(1); // Hücre değerlerini al
      if (classInfo === `${department} ${grade}. Sınıf`) {
        schedule.push({ day, time, courseName, instructor, classInfo });
      }
    });

    return schedule;
  }
}

module.exports = new ExcelService();
