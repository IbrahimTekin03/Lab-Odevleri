const express = require("express");
const router = express.Router();
const ScheduleController = require("../controller/scheduleController");
const courseModel = require("../models/courseModel");
const classroomModel = require("../models/classroomModel");
const departmentModel = require("../models/departmentModel");
const excelService = require("../services/excelService");
const authMiddleware = require("../middleware/authMiddleware");
const roleMiddleware = require("../middleware/roleMiddleware");
const passwordMiddleware = require("../middleware/passwordMiddleware");
const User = require("../models/userModel");
const Role = require("../models/roleModel");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const db = require("../db/dbConnection");

const scheduleController = new ScheduleController(
  courseModel,
  classroomModel,
  departmentModel,
  excelService
);

router.post("/generate-schedule", (req, res) =>
  scheduleController.generateSchedule(req, res)
);
router.post("/update-schedule", (req, res) =>
  scheduleController.updateSchedule(req, res)
);

module.exports = router;
// Tüm kullanıcıları getir (Sadece admin erişebilir)
router.get(
  "/getAllUsers",
  authMiddleware,
  roleMiddleware(["admin"]),
  async (req, res, next) => {
    try {
      const tumUserlar = await User.findAll();
      const usersWithoutPassword = tumUserlar.map((user) => {
        const userObject = user.toJSON();
        delete userObject.sifre;
        return userObject;
      });
      res.json(usersWithoutPassword);
    } catch (error) {
      next(createError(400, error));
    }
  }
);

// Belirli bir kullanıcıyı getir (Admin ve kullanıcı kendisi erişebilir)
router.get(
  "/getUser/:id",
  authMiddleware,
  roleMiddleware(["admin", "user"]),
  async (req, res, next) => {
    try {
      const user = await User.findByPk(req.params.id);
      if (!user) {
        throw createError(404, "Kullanıcı bulunamadı");
      }
      const userObject = user.toJSON();
      delete userObject.sifre;
      res.json(userObject);
    } catch (error) {
      next(createError(400, error));
    }
  }
);

router.delete("/:OgrenciNo", async (req, res, next) => {
  try {
    const sonuc = await User.destroy({
      where: { OgrenciNo: req.params.OgrenciNo },
    });
    if (sonuc) {
      res.json({
        mesaj: "No'su : " + req.params.OgrenciNo + " olan kullanıcı silindi",
      });
    } else {
      throw createError(404, "silinecek kullanıcı bulunamadı");
    }
  } catch (error) {
    next(createError(400, error));
  }
});

router.patch("/:id", async (req, res, next) => {
  if (req.body.hasOwnProperty("sifre")) {
    req.body.sifre = await bcrypt.hash(req.body.sifre, 10);
  }

  const { error, value } = User.joiValidationForUpdate(req.body);
  if (error) {
    return next(createError(400, error));
  } else {
    try {
      const sonuc = await User.update(req.body, {
        where: { id: req.params.id },
        returning: true,
        plain: true,
      });
      if (sonuc) {
        const updatedUser = sonuc[1].toJSON();
        delete updatedUser.sifre;
        return res.json(updatedUser);
      } else {
        return res
          .status(404)
          .json({ mesaj: "güncellenecek kullanıcı bulunamadı" });
      }
    } catch (error) {
      next(createError(400, error));
    }
  }
});

router.post("/register", async (req, res, next) => {
  try {
    const { isim, OgrenciNo, sifre, bolum, sinif } = req.body;

    // Öğrenci numarasının benzersiz olup olmadığını kontrol et
    const existingOgrenciNo = await User.findOne({
      where: { OgrenciNo },
    });
    if (existingOgrenciNo) {
      throw createError(400, "Bu Öğrenci Numarası zaten kullanılıyor.");
    }

    // Şifreyi hashle
    const hashedPassword = await bcrypt.hash(sifre, 10);

    // Yeni kullanıcı oluştur
    const newUser = await User.create({
      isim,
      OgrenciNo,
      sifre: hashedPassword,
      bolum,
      sinif,
    });

    // Kullanıcıya "user" rolünü ata
    const userRole = await Role.findOne({ where: { name: "Student" } });
    if (!userRole) {
      throw createError(400, "Student rolü bulunamadı.");
    }
    await newUser.addRole(userRole);

    // Kullanıcıyı rollerle birlikte yeniden yükle
    const userWithRoles = await User.findByPk(newUser.id, {
      include: { model: Role, through: { attributes: [] } },
    });

    // Token oluştur
    const token = jwt.sign(
      {
        _id: userWithRoles.id,
        roles: userWithRoles.Roles.map((role) => role.name),
      },
      "secretkey",
      { expiresIn: "2h" }
    );

    // Şifreyi ve diğer hassas bilgileri kaldır
    const userObject = userWithRoles.toJSON();
    delete userObject.sifre;
    delete userObject.createdAt;
    delete userObject.updatedAt;

    // Yanıt olarak kullanıcı bilgilerini ve tokeni döndür
    res.status(201).json({ user: userObject, token });
  } catch (error) {
    next(error);
    console.error("Kullanıcı kaydederken hata: " + error.message);
  }
});

router.post("/login", passwordMiddleware, async (req, res) => {
  try {
    const token = await req.user.generateToken();
    const userObject = req.user.toJSON();
    delete userObject.sifre;
    delete userObject.createdAt;
    delete userObject.updatedAt;

    // Kullanıcının rollerini ekleyin
    const roles = await req.user.getRoles(); // Roller ilişkisini yükleyin
    userObject.roles = roles.map((role) => role.name);

    res.status(200).json({ user: userObject, token });
  } catch (error) {
    res.status(500).json({ message: "Bir hata oluştu", error: error.message });
  }
});

router.post("/addAdmin", async (req, res, next) => {
  try {
    // Admin rolünü alın
    const adminRole = await Role.findOne({ where: { name: "admin" } });
    if (!adminRole) {
      throw createError(400, "Admin rolü bulunamadı.");
    }

    // Yeni kullanıcı oluştur
    const hashedPassword = await bcrypt.hash(req.body.sifre, 10);
    const adminUser = await User.create({
      isim: req.body.isim,
      OgrenciNo: req.body.OgrenciNo,
      sifre: hashedPassword,
    });

    // Kullanıcıya admin rolünü ata
    await adminUser.addRole(adminRole);

    // Kullanıcıyı rollerle birlikte yeniden yükle
    const adminUserWithRoles = await User.findByPk(adminUser.id, {
      include: { model: Role, through: { attributes: [] } },
    });

    // Token oluştur ve konsola yazdır
    const token = await adminUserWithRoles.generateToken();
    console.log("Admin için oluşturulan token:", token);

    res
      .status(201)
      .json({ mesaj: "Admin kullanıcı başarıyla eklendi.", token });
  } catch (error) {
    if (error.name === "SequelizeValidationError") {
      return res
        .status(400)
        .json({ mesaj: "Doğrulama hatası: " + error.errors[0].message });
    }
    next(error);
  }
});

router.post("/registerTeacher", async (req, res, next) => {
  try {
    const { isim, OgrenciNo, sifre } = req.body;

    // Tüm alanların doldurulup doldurulmadığını kontrol et
    if (!isim || !OgrenciNo || !sifre) {
      return res.status(400).json({ message: "Tüm alanlar doldurulmalıdır." });
    }

    // Öğrenci numarasının benzersiz olup olmadığını kontrol et
    const existingOgrenciNo = await User.findOne({
      where: { OgrenciNo },
    });
    if (existingOgrenciNo) {
      return res
        .status(400)
        .json({ message: "Bu Öğrenci Numarası zaten kullanılıyor." });
    }

    // Şifreyi hashle
    const hashedPassword = await bcrypt.hash(sifre, 10);

    // Yeni kullanıcı oluştur
    const newTeacher = await User.create({
      isim,
      OgrenciNo,
      sifre: hashedPassword,
    });

    // Kullanıcıya "teacher" rolünü ata
    const teacherRole = await Role.findOne({ where: { name: "teacher" } });
    if (!teacherRole) {
      return res.status(400).json({ message: "Teacher rolü bulunamadı." });
    }
    await newTeacher.addRole(teacherRole);

    // Kullanıcıyı rollerle birlikte yeniden yükle
    const teacherWithRoles = await User.findByPk(newTeacher.id, {
      include: { model: Role, through: { attributes: [] } },
    });

    // Şifreyi ve diğer hassas bilgileri kaldır
    const teacherObject = teacherWithRoles.toJSON();
    delete teacherObject.sifre;

    res.status(201).json({
      message: "Öğretmen başarıyla kaydedildi.",
      teacher: teacherObject,
    });
  } catch (error) {
    console.error("Öğretmen kaydedilirken bir hata oluştu:", error.message);
    next(error);
  }
});

router.post("/loginTeacher", async (req, res, next) => {
  try {
    const { OgrenciNo, sifre } = req.body;

    // Tüm alanların doldurulup doldurulmadığını kontrol et
    if (!OgrenciNo || !sifre) {
      return res.status(400).json({ message: "Tüm alanlar doldurulmalıdır." });
    }

    // Kullanıcıyı veritabanında ara
    const teacher = await User.findOne({
      where: { OgrenciNo },
      include: { model: Role, through: { attributes: [] } },
    });

    if (!teacher) {
      return res.status(404).json({ message: "Kullanıcı bulunamadı." });
    }

    // Şifreyi doğrula
    const isPasswordValid = await bcrypt.compare(sifre, teacher.sifre);
    if (!isPasswordValid) {
      return res.status(401).json({ message: "Geçersiz şifre." });
    }

    // Token oluştur
    const token = jwt.sign(
      {
        id: teacher.id,
        isim: teacher.isim,
        roles: teacher.Roles.map((role) => role.name),
      },
      "secretkey",
      { expiresIn: "2h" }
    );

    // Şifreyi ve diğer hassas bilgileri kaldır
    const teacherObject = teacher.toJSON();
    delete teacherObject.sifre;

    res.status(200).json({
      message: "Giriş başarılı.",
      token,
      teacher: teacherObject,
    });
  } catch (error) {
    console.error("Giriş yapılırken bir hata oluştu:", error.message);
    next(error);
  }
});

module.exports = router;
