const express = require("express");
const db = require("../db/dbConnection");
const router = express.Router();
const ScheduleController = require("../controller/scheduleController");
const courseModel = require("../models/courseModel");
const classroomModel = require("../models/classroomModel");
const departmentModel = require("../models/departmentModel");
const excelService = require("../services/excelService");
const Course = require("../models/courseModel"); // Course modelini import ettik

const scheduleController = new ScheduleController(
  courseModel,
  classroomModel,
  departmentModel,
  excelService
);

router.post("/generate-schedule", (req, res) =>
  scheduleController.generateSchedule(req, res)
);
router.post("/update-schedule", (req, res) =>
  scheduleController.updateSchedule(req, res)
);

// Ders Ekleme
router.post("/addCourse", async (req, res, next) => {
  try {
    console.log("Request Body:", req.body); // Gönderilen verileri loglayın

    const {
      name,
      code,
      weekly_hours,
      instructor_name,
      DersiHangiBolumAliyor,
      HangiSinif,
      AyniDersiAlanBolum,
      HangiIkincilSinif,
      DersOnlineMi,
      DersiAlanKisiSayisi = 0, // Varsayılan değer olarak 0 atanıyor
    } = req.body;

    // Eksik alanları kontrol edin
    if (
      !name ||
      !code ||
      !weekly_hours ||
      !instructor_name ||
      !DersiHangiBolumAliyor ||
      !HangiSinif
    ) {
      return res
        .status(400)
        .json({ message: "Tüm zorunlu alanları doldurun." });
    }

    const newCourse = await Course.create({
      name,
      code,
      weekly_hours: parseInt(weekly_hours), // String yerine integer olarak gönderiliyor
      instructor_name,
      DersiHangiBolumAliyor,
      HangiSinif: parseInt(HangiSinif), // String yerine integer olarak gönderiliyor
      AyniDersiAlanBolum,
      HangiIkincilSinif: parseInt(HangiIkincilSinif) || null, // Null kontrolü
      DersOnlineMi: parseInt(DersOnlineMi), // Boolean yerine integer olarak gönderiliyor
      DersiAlanKisiSayisi, // Varsayılan değer burada kullanılıyor
    });

    res
      .status(201)
      .json({ message: "Ders başarıyla eklendi.", course: newCourse });
  } catch (error) {
    console.error("Hata:", error.message); // Hata mesajını loglayın
    if (error.name === "SequelizeValidationError") {
      return res
        .status(400)
        .json({ message: "Doğrulama hatası: " + error.errors[0].message });
    }
    next(error);
  }
});

// Ders Silme
router.delete("/deleteCourse/:code", async (req, res, next) => {
  try {
    const courseId = req.params.code;

    const deletedCourse = await Course.destroy({ where: { code: courseId } });

    if (!deletedCourse) {
      throw createError(404, "Silinecek ders bulunamadı.");
    }

    res.status(200).json({ message: "Ders başarıyla silindi." });
  } catch (error) {
    next(error);
  }
});

router.get("/courses", async (req, res) => {
  try {
    const [courses] = await db.query("SELECT code, name FROM courses");
    console.log(courses); // Konsolda nasıl geliyor görelim
    res.json(courses);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Dersleri alırken hata oluştu." });
  }
});

module.exports = router;
