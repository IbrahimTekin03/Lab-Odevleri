const express = require("express");
const router = express.Router();
const authMiddleware = require("../middleware/authMiddleware");
const excelService = require("../services/excelService");
const path = require("path");
const db = require("../db/dbConnection"); // Veritabanı bağlantısını ayarlayın
const bcrypt = require("bcrypt");
const sequelize = require("../db/dbConnection"); // Sequelize'yi import edin

router.get("/own-schedule", authMiddleware, async (req, res) => {
  try {
    const teacherName = req.user.isim; // authMiddleware'den gelen öğretmen ismi

    if (!teacherName) {
      return res.status(400).json({ message: "Öğretmen ismi eksik." });
    }

    console.log("Teacher Name:", teacherName); // Debugging için log ekleyin

    // schedules tablosundan öğretmenin ders programını al
    const query = `
      SELECT DISTINCT day, time, course_name, instructor, department, grade, classroom 
      FROM schedules 
      WHERE instructor = ?
      GROUP BY day, time, course_name, instructor, department, grade, classroom
    `;
    const schedules = await sequelize.query(query, {
      replacements: [teacherName],
      type: sequelize.QueryTypes.SELECT,
    });

    if (schedules.length === 0) {
      return res.status(404).json({ message: "Ders programı bulunamadı." });
    }

    res.status(200).json(schedules);
  } catch (error) {
    console.error("Ders programı alınırken bir hata oluştu:", error.message);
    res
      .status(500)
      .json({ message: "Ders programı alınırken bir hata oluştu." });
  }
});

// Seçilen öğretim üyesinin ders programını getir
router.get("/schedule/:teacherName", authMiddleware, async (req, res) => {
  try {
    const teacherName = req.params.teacherName;

    if (!teacherName) {
      return res.status(400).json({ message: "Öğretim üyesi ismi eksik." });
    }

    console.log("Selected Teacher Name:", teacherName);

    const query = `
      SELECT day, time, course_name, instructor, department, grade, classroom 
      FROM schedules 
      WHERE instructor = ?
    `;
    const schedules = await sequelize.query(query, {
      replacements: [teacherName],
      type: sequelize.QueryTypes.SELECT,
    });

    if (schedules.length === 0) {
      return res.status(404).json({ message: "Ders programı bulunamadı." });
    }

    res.status(200).json(schedules);
  } catch (error) {
    console.error("Ders programı alınırken bir hata oluştu:", error.message);
    res
      .status(500)
      .json({ message: "Ders programı alınırken bir hata oluştu." });
  }
});

router.get("/class-schedule", authMiddleware, async (req, res) => {
  try {
    let { department, grade } = req.query;

    if (!department || !grade) {
      return res.status(400).json({ message: "Bölüm ve sınıf bilgisi eksik." });
    }

    // Grade değerini dönüştür
    grade = `${grade}. Sınıf`;

    console.log("Selected Department:", department);
    console.log("Selected Grade:", grade);

    const query = `
      SELECT day, time, course_name, instructor, department, grade, classroom 
      FROM schedules 
      WHERE department = ? AND grade = ?
    `;
    const schedules = await sequelize.query(query, {
      replacements: [department, grade],
      type: sequelize.QueryTypes.SELECT,
    });

    if (schedules.length === 0) {
      return res.status(404).json({ message: "Ders programı bulunamadı." });
    }

    res.status(200).json(schedules);
  } catch (error) {
    console.error("Ders programı alınırken bir hata oluştu:", error.message);
    res
      .status(500)
      .json({ message: "Ders programı alınırken bir hata oluştu." });
  }
});

router.get("/teachers", async (req, res) => {
  try {
    const [results] = await db.query(`
        SELECT u.id, u.isim AS name
        FROM users u
        INNER JOIN user_roles ur ON u.id = ur.userId
        WHERE ur.roleId = 3
      `);
    res.json(results);
  } catch (error) {
    console.error(
      "Öğretim görevlileri alınırken bir hata oluştu:",
      error.message
    );
    res
      .status(500)
      .json({ message: "Öğretim görevlileri alınırken bir hata oluştu." });
  }
});

router.get("/departments", async (req, res) => {
  try {
    const [results] = await db.query(`
        SELECT id, name
        FROM departments
      `);
    res.json(results);
  } catch (error) {
    console.error("Bölümler alınırken bir hata oluştu:", error.message);
    res.status(500).json({ message: "Bölümler alınırken bir hata oluştu." });
  }
});

module.exports = router;
