const express = require("express");
const studentController = require("../controller/studentController");
const authMiddleware = require("../middleware/authMiddleware");

const router = express.Router();

// Öğrenci rotaları
router.get("/student/courses", authMiddleware, studentController.getCourses);
router.post(
  "/student/save-courses",
  authMiddleware,
  studentController.saveCourses
);
router.get("/student/schedule", authMiddleware, studentController.getSchedule); // 💪 Eksik olan rota eklendi

module.exports = router;
