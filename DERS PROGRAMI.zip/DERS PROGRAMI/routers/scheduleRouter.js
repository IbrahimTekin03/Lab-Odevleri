const express = require("express");
const router = express.Router();
const ScheduleController = require("../controller/scheduleController");
// Modelleri ve gerekli servisleri import edin
const courseModel = require("../models/courseModel");
const classroomModel = require("../models/classroomModel");
const departmentModel = require("../models/departmentModel");
const excelService = require("../services/excelService");
const usersModel = require("../models/userModel"); // Kullanıcı modelini import edin
const db = require("../db/dbConnection"); // Veritabanı bağlantısını import edin

// ScheduleController örneğini oluşturun
const scheduleController = new ScheduleController(
  courseModel,
  classroomModel,
  departmentModel,
  excelService,
  usersModel
);

// Route tanımlayın
router.post("/generate-schedule", (req, res) =>
  scheduleController.generateSchedule(req, res)
);

router.get("/available-slots/:code", async (req, res) => {
  const courseCode = req.params.code;
  try {
    const availableSlots = await scheduleController.getAvailableSlots(
      courseCode
    );
    res.status(200).json(availableSlots);
  } catch (error) {
    res.status(500).json({
      message: "Boş saatler alınırken bir hata oluştu.",
      error: error.message,
    });
  }
});

router.get("/get-schedule", async (req, res) => {
  try {
    const schedules = await db.query("SELECT * FROM schedules"); // Veritabanından verileri al
    console.log("Dönen veri:", schedules); // Gelen veriyi logla
    res.json(schedules); // JSON formatında döndür
  } catch (error) {
    res
      .status(500)
      .json({
        message: "Ders programı alınırken hata oluştu.",
        error: error.message,
      });
  }
});

router.post("/update-schedule", async (req, res) => {
  const updatedSchedule = req.body;

  try {
    for (const entry of updatedSchedule) {
      await db.query(
        `UPDATE schedules SET course_name = ?, instructor = ?, classroom = ? WHERE day = ? AND time = ?`,
        [
          entry.course_name,
          entry.instructor,
          entry.classroom,
          entry.day,
          entry.time,
        ]
      );
    }
    res.json({ message: "Ders programı başarıyla güncellendi." });
  } catch (error) {
    res.status(500).json({
      message: "Ders programı güncellenirken hata oluştu.",
      error: error.message,
    });
  }
});



module.exports = router;
