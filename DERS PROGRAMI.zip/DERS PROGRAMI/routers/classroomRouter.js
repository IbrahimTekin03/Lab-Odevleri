const express = require('express');
const router = express.Router();
const ScheduleController = require('../controller/scheduleController');
const courseModel = require('../models/courseModel');
const classroomModel = require('../models/classroomModel');
const departmentModel = require('../models/departmentModel');
const excelService = require('../services/excelService');

const scheduleController = new ScheduleController(courseModel, classroomModel, departmentModel, excelService);

router.post('/generate-schedule', (req, res) => scheduleController.generateSchedule(req, res));
router.post('/update-schedule', (req, res) => scheduleController.updateSchedule(req, res));

module.exports = router;
// Derslik Ekleme
router.post("/addClassroom", async (req, res, next) => {
  try {
    const { name, capacity, type } = req.body;

    // Eksik alanları kontrol edin
    if (!name || !capacity || !type) {
      return res.status(400).json({ message: "Tüm alanları doldurun." });
    }

    const newClassroom = await Classroom.create({ name, capacity, type });

    res
      .status(201)
      .json({ message: "Derslik başarıyla eklendi.", classroom: newClassroom });
  } catch (error) {
    next(error);
  }
});

// Derslik Silme
router.delete("/deleteClassroom/:id", async (req, res, next) => {
  try {
    const classroomId = req.params.id;

    const deletedClassroom = await Classroom.destroy({
      where: { id: classroomId },
    });

    if (!deletedClassroom) {
      throw createError(404, "Silinecek derslik bulunamadı.");
    }

    res.status(200).json({ message: "Derslik başarıyla silindi." });
  } catch (error) {
    next(error);
  }
});

module.exports = router;
