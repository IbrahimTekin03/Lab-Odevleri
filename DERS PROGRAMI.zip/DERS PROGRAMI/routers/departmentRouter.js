const express = require("express");
const router = express.Router();
const Department = require("../models/departmentModel"); // Department modelini import ettik
const ScheduleController = require("../controller/scheduleController");
const courseModel = require("../models/courseModel");
const classroomModel = require("../models/classroomModel");
const excelService = require("../services/excelService");

const scheduleController = new ScheduleController(
  courseModel,
  classroomModel,
  Department,
  excelService
);

router.post("/generate-schedule", (req, res) =>
  scheduleController.generateSchedule(req, res)
);
router.post("/update-schedule", (req, res) =>
  scheduleController.updateSchedule(req, res)
);

// Bölüm Ekleme
router.post("/addDepartment", async (req, res, next) => {
  try {
    const { name, code } = req.body;

    const newDepartment = await Department.create({ name, code });

    res
      .status(201)
      .json({ message: "Bölüm başarıyla eklendi.", department: newDepartment });
  } catch (error) {
    if (error.name === "SequelizeValidationError") {
      return res
        .status(400)
        .json({ message: "Doğrulama hatası: " + error.errors[0].message });
    }
    next(error);
  }
});

// Bölüm Silme
router.delete("/deleteDepartment/:code", async (req, res, next) => {
  try {
    const departmentId = req.params.code;

    const deletedDepartment = await Department.destroy({
      where: { code: departmentId },
    });

    if (!deletedDepartment) {
      throw createError(404, "Silinecek bölüm bulunamadı.");
    }

    res.status(200).json({ message: "Bölüm başarıyla silindi." });
  } catch (error) {
    next(error);
  }
});

module.exports = router;
