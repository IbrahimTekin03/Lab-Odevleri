const db = require("../db/dbConnection"); // Veritabanı bağlantısı
const Course = require("../models/courseModel"); // Ders modeli
const User = require("../models/userModel"); // Kullanıcı modeli

class TeacherController {
  // Giriş yapan öğretim üyesinin kendi ders programını getir
  async getOwnSchedule(req, res) {
    try {
      const teacherId = req.user.id; // Giriş yapan öğretim üyesinin ID'si

      const schedule = await Course.findAll({
        where: { teacherId }, // teacherId'ye göre filtrele
        attributes: ["name", "day", "time"], // Sadece gerekli alanları al
      });

      res.json(schedule);
    } catch (error) {
      console.error("Kendi ders programı alınırken bir hata oluştu:", error);
      res
        .status(500)
        .json({ message: "Kendi ders programı alınırken bir hata oluştu." });
    }
  }

  // Seçilen öğretim üyesinin ders programını getir
  async getSelectedTeacherSchedule(req, res) {
    try {
      const { teacherId } = req.params; // Seçilen öğretim üyesinin ID'si

      const schedule = await Course.findAll({
        where: { teacherId }, // teacherId'ye göre filtrele
        attributes: ["name", "day", "time"], // Sadece gerekli alanları al
      });

      res.json(schedule);
    } catch (error) {
      console.error(
        "Seçilen öğretim üyesinin ders programı alınırken bir hata oluştu:",
        error
      );
      res
        .status(500)
        .json({
          message:
            "Seçilen öğretim üyesinin ders programı alınırken bir hata oluştu.",
        });
    }
  }

  // Seçilen bölüm ve sınıfın ders programını getir
  async getClassSchedule(req, res) {
    try {
      const { department, grade } = req.query; // Bölüm ve sınıf bilgileri

      const schedule = await Course.findAll({
        where: {
          department, // Bölüme göre filtrele
          grade, // Sınıfa göre filtrele
        },
        attributes: ["name", "day", "time"], // Sadece gerekli alanları al
      });

      res.json(schedule);
    } catch (error) {
      console.error(
        "Seçilen bölüm ve sınıfın ders programı alınırken bir hata oluştu:",
        error
      );
      res
        .status(500)
        .json({
          message:
            "Seçilen bölüm ve sınıfın ders programı alınırken bir hata oluştu.",
        });
    }
  }
}

module.exports = new TeacherController();
