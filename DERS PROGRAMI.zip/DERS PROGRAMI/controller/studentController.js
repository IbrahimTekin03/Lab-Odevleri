const User = require("../models/userModel"); // Kullanıcı modeli
const Course = require("../models/courseModel"); // Kurs modeli
const sequelize = require("../db/dbConnection"); // Doğrudan sequelize'u al
const { Op, QueryTypes } = require("sequelize"); // Sequelize'den Op ve QueryTypes çek

class StudentController {
  async getCourses(req, res) {
    try {
      const userId = req.user?.id;

      console.log("User ID:", userId);

      if (!userId) {
        return res.status(400).json({ message: "Kullanıcı kimliği eksik." });
      }

      const user = await User.findByPk(userId);

      if (!user) {
        return res.status(404).json({ message: "Kullanıcı bulunamadı." });
      }

      const { bolum, sinif } = user;

      if (!bolum || !sinif) {
        return res
          .status(400)
          .json({ message: "Bölüm ve sınıf bilgisi eksik." });
      }

      console.log("Bölüm:", bolum);
      console.log("Sınıf:", sinif);

      const courses = await Course.findAll({
        attributes: ["name"],
        where: {
          [Op.or]: [
            { DersiHangiBolumAliyor: bolum, HangiSinif: sinif },
            { AyniDersiAlanBolum: bolum, HangiIkincilSinif: sinif },
          ],
        },
      });

      res.json(courses);
    } catch (error) {
      console.error("Dersler alınırken bir hata oluştu:", error.message);
      console.error("Hata detayları:", error);
      res.status(500).json({ message: "Dersler alınırken bir hata oluştu." });
    }
  }

  async saveCourses(req, res) {
    try {
      const { selectedCourses } = req.body;

      if (!selectedCourses || selectedCourses.length === 0) {
        return res.status(400).json({ message: "Seçilen dersler eksik." });
      }

      for (const courseName of selectedCourses) {
        await Course.increment("DersiAlanKisiSayisi", {
          by: 1,
          where: { name: courseName },
        });
      }

      res.json({ message: "Dersler başarıyla kaydedildi." });
    } catch (error) {
      console.error("Dersler kaydedilirken bir hata oluştu:", error.message);
      res
        .status(500)
        .json({ message: "Dersler kaydedilirken bir hata oluştu." });
    }
  }

  async getSchedule(req, res) {
    try {
      const userId = req.user?.id;

      if (!userId) {
        return res.status(400).json({ message: "Kullanıcı kimliği eksik." });
      }

      const user = await User.findByPk(userId);

      if (!user) {
        return res.status(404).json({ message: "Kullanıcı bulunamadı." });
      }

      const { bolum, sinif } = user;

      if (!bolum || !sinif) {
        return res
          .status(400)
          .json({ message: "Bölüm ve sınıf bilgisi eksik." });
      }

      const department =
        bolum === "YZM" ? "Yazılım Mühendisliği" : "Bilgisayar Mühendisliği";
      const grade = `${sinif}. Sınıf`;

      console.log("Department:", department);
      console.log("Grade:", grade);

      // Doğrudan sequelize ile query çalıştır
      const schedules = await sequelize.query(
        `
          SELECT day, time, course_name, instructor, department, grade, classroom
          FROM schedules
          WHERE department = :department AND grade = :grade
        `,
        {
          replacements: { department, grade },
          type: QueryTypes.SELECT,
        }
      );

      if (schedules.length === 0) {
        return res.status(404).json({ message: "Ders programı bulunamadı." });
      }

      res.json(schedules);
    } catch (error) {
      console.error("Ders programı alınırken bir hata oluştu:", error.message);
      res
        .status(500)
        .json({ message: "Ders programı alınırken bir hata oluştu." });
    }
  }
}

module.exports = new StudentController();
