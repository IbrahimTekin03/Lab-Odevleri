const path = require("path");
const courseModel = require("../models/courseModel");
const db = require("../db/dbConnection");

class ScheduleController {
  constructor(
    courseModel,
    classroomModel,
    departmentModel,
    excelService,
    usersModel
  ) {
    this.courseModel = courseModel;
    this.classroomModel = classroomModel;
    this.departmentModel = departmentModel;
    this.excelService = excelService;
    this.usersModel = usersModel;
  }

  async getStudentCountForCourse(course) {
    const primaryStudents = await this.usersModel.count({
      where: {
        bolum: course.DersiHangiBolumAliyor,
        sinif: course.HangiSinif,
      },
    });

    let secondaryStudents = 0;
    if (course.AyniDersiAlanBolum && course.HangiIkincilSinif) {
      secondaryStudents = await this.usersModel.count({
        where: {
          bolum: course.AyniDersiAlanBolum,
          sinif: course.HangiIkincilSinif,
        },
      });
    }

    const toplam = primaryStudents + secondaryStudents;

    return toplam;
  }

  async generateSchedule(req, res) {
    try {
      const courses = await this.courseModel.findAll();
      const classrooms = await this.classroomModel.findAll();
      const departments = await this.departmentModel.findAll();

      // Ders programını oluştur
      const scheduleData = await this.createSchedule(
        courses,
        classrooms,
        departments
      );

      if (!scheduleData || Object.keys(scheduleData).length === 0) {
        return res.status(400).json({
          message: "Ders programı oluşturulamadı. Veriler eksik veya hatalı.",
        });
      }

      // Veritabanına kaydetme işlemi
      for (const department of departments) {
        const departmentName = department.name;
        const departmentSchedule = scheduleData[departmentName];

        if (!departmentSchedule) {
          console.warn(`Bölüm için program bulunamadı: ${departmentName}`);
          continue;
        }

        // Mevcut verileri sil
        await this.clearScheduleFromDB(departmentName);

        // Yeni verileri ekle
        await this.saveScheduleToDB(departmentName, departmentSchedule);

        // Excel dosyasını oluştur
        const excelFilePath = await this.excelService.generateScheduleExcel(
          departmentSchedule,
          departmentName
        );

        console.log(`Excel dosyası oluşturuldu: ${excelFilePath}`);
      }

      res
        .status(200)
        .json({ message: "Ders programları başarıyla oluşturuldu." });
    } catch (error) {
      console.error("Hata:", error.message);
      res.status(500).json({
        message: "Ders programı oluşturulurken bir hata oluştu.",
        error: error.message,
      });
    }
  }

  async updateSchedule(req, res) {
    try {
      const courses = await this.courseModel.findAll();
      const classrooms = await this.classroomModel.findAll();
      const departments = await this.departmentModel.findAll();

      if (!courses.length || !classrooms.length || !departments.length) {
        return res.status(400).json({ message: "Gerekli veriler eksik." });
      }

      const scheduleData = this.createSchedule(
        courses,
        classrooms,
        departments
      );
      const excelFilePath = await this.excelService.generateScheduleExcel(
        scheduleData
      );

      res.status(200).json({
        message: "Ders programı başarıyla güncellendi.",
        filePath: excelFilePath,
      });
    } catch (error) {
      console.error("Hata:", error.message);
      res.status(500).json({
        message: "Ders programı güncellenirken bir hata oluştu.",
        error: error.message,
      });
    }
  }

  async createSchedule(courses, classrooms, departments) {
    const gunler = ["Pazartesi", "Salı", "Çarşamba", "Perşembe", "Cuma"];
    const saatler = [
      "09:00-10:00",
      "10:00-11:00",
      "11:00-12:00",
      "13:00-14:00",
      "14:00-15:00",
      "15:00-16:00",
      "16:00-17:00",
    ];

    let program = {};

    // Her bölüm ve her sınıf için ayrı bir program oluştur
    departments.forEach((department) => {
      program[department.name] = {};
      for (let sinif = 1; sinif <= 4; sinif++) {
        program[department.name][`${sinif}. Sınıf`] = {};
        gunler.forEach((gun) => {
          program[department.name][`${sinif}. Sınıf`][gun] = {};
          saatler.forEach((saat) => {
            program[department.name][`${sinif}. Sınıf`][gun][saat] = null;
          });
        });
      }
    });

    for (const course of courses) {
      const primaryDepartment = departments.find(
        (dept) => dept.code === course.DersiHangiBolumAliyor
      );

      if (!primaryDepartment) {
        console.warn(`Bölüm bulunamadı: ${course.DersiHangiBolumAliyor}`);
        continue;
      }

      const primaryDepartmentName = primaryDepartment.name;
      const primaryClass = `${course.HangiSinif}. Sınıf`;
      const sinifTuru = course.DersOnlineMi ? "ONLINE" : "NORMAL";
      let saatKalan = course.weekly_hours;

      // Ortak ders için ikincil bölüm ve sınıf bilgilerini al
      const secondaryDepartment = course.AyniDersiAlanBolum
        ? departments.find((dept) => dept.code === course.AyniDersiAlanBolum)
        : null;
      const secondaryDepartmentName = secondaryDepartment
        ? secondaryDepartment.name
        : null;
      const secondaryClass = course.HangiIkincilSinif
        ? `${course.HangiIkincilSinif}. Sınıf`
        : null;

      // Dersleri günlere eşit şekilde dağıtmak için gün sırasını karıştır
      const shuffledGunler = [...gunler].sort(() => Math.random() - 0.5);

      for (let gun of shuffledGunler) {
        for (let saat of saatler) {
          if (saatKalan <= 0) break;

          // Bu saate zaten ders yerleştirilmiş mi?
          if (
            program[primaryDepartmentName][primaryClass][gun][saat] ||
            (secondaryDepartmentName &&
              program[secondaryDepartmentName] &&
              program[secondaryDepartmentName][secondaryClass] &&
              program[secondaryDepartmentName][secondaryClass][gun][saat])
          ) {
            continue;
          }

          const uygunSinif = classrooms.find((sinif) => {
            if (
              sinif.type !== sinifTuru &&
              !course.DersOnlineMi // Online dersler için sınıf kontrolü yapılmaz
            ) {
              return false;
            }

            if (
              !course.DersOnlineMi &&
              sinif.capacity < course.DersiAlanKisiSayisi
            ) {
              return false;
            }

            // Tüm bölümler ve saatlere bakarak bu sınıf kullanılmış mı kontrolü
            for (const deptName of Object.keys(program)) {
              for (const className of Object.keys(program[deptName])) {
                if (
                  program[deptName][className][gun] &&
                  program[deptName][className][gun][saat] &&
                  program[deptName][className][gun][saat].classroom ===
                    sinif.name
                ) {
                  return false;
                }
              }
            }

            return true;
          });

          if (uygunSinif || course.DersOnlineMi) {
            // Ana bölüme dersi yerleştir
            program[primaryDepartmentName][primaryClass][gun][saat] = {
              courseName: course.name,
              instructor: course.instructor_name,
              classroom: course.DersOnlineMi ? "ONLINE" : uygunSinif.name,
            };

            // Ortak ders ise ikincil bölüme de dersi yerleştir
            if (secondaryDepartmentName && secondaryClass) {
              program[secondaryDepartmentName][secondaryClass][gun][saat] = {
                courseName: course.name,
                instructor: course.instructor_name,
                classroom: course.DersOnlineMi ? "ONLINE" : uygunSinif.name,
              };
            }

            saatKalan--;
          }
        }
      }

      // Eğer dersin tüm saatleri yerleştirilemediyse uyarı ver
      if (saatKalan > 0) {
        console.warn(
          `Ders: ${course.name} için yeterli saat bulunamadı. Kalan saat: ${saatKalan}`
        );
      }
    }

    // Bölüm ve sınıf bazında programı logla
    Object.keys(program).forEach((departmentName) => {
      Object.keys(program[departmentName]).forEach((className) => {
        console.log(`${departmentName} ${className}:`);
        console.log(
          JSON.stringify(program[departmentName][className], null, 2)
        );
      });
    });

    return program;
  }

  async clearScheduleFromDB(departmentName) {
    try {
      await this.courseModel.sequelize.query(
        `DELETE FROM schedules WHERE department = ?`,
        { replacements: [departmentName] }
      );
      console.log(`Mevcut veriler silindi: ${departmentName}`);
    } catch (error) {
      console.error(
        "Veritabanından veri silinirken bir hata oluştu:",
        error.message
      );
      throw error;
    }
  }

  async saveScheduleToDB(departmentName, scheduleData) {
    try {
      const schedules = [];

      for (const [className, days] of Object.entries(scheduleData)) {
        for (const [day, hours] of Object.entries(days)) {
          for (const [time, lesson] of Object.entries(hours)) {
            if (!lesson) continue;

            schedules.push({
              department: departmentName,
              grade: className,
              day,
              time,
              course_name: lesson.courseName,
              instructor: lesson.instructor,
              classroom: lesson.classroom,
            });
          }
        }
      }

      // Veritabanına toplu ekleme
      await this.courseModel.sequelize
        .getQueryInterface()
        .bulkInsert("schedules", schedules);
      console.log(`Yeni veriler kaydedildi: ${departmentName}`);
    } catch (error) {
      console.error(
        "Veritabanına veri eklenirken bir hata oluştu:",
        error.message
      );
      throw error;
    }
  }

  async getAvailableSlots(courseCode) {
    try {
      const course = await this.courseModel.findOne({
        where: { code: courseCode },
      });
      if (!course) {
        throw new Error("Ders bulunamadı.");
      }

      const gunler = ["Pazartesi", "Salı", "Çarşamba", "Perşembe", "Cuma"];
      const saatler = [
        "09:00-10:00",
        "10:00-11:00",
        "11:00-12:00",
        "13:00-14:00",
        "14:00-15:00",
        "15:00-16:00",
        "16:00-17:00",
      ];

      const availableSlots = [];
      for (const gun of gunler) {
        for (const saat of saatler) {
          // Dersliklerin müsait olup olmadığını kontrol et
          const isOccupied = await this.courseModel.sequelize.query(
            `SELECT * FROM schedules WHERE day = ? AND time = ? AND (classroom = ? OR classroom IS NULL)`,
            { replacements: [gun, saat, course.DersOnlineMi ? "ONLINE" : null] }
          );

          // Eğer derslik dolu değilse, uygun derslikleri sorgula
          if (!isOccupied[0].length) {
            // classrooms tablosundan derslik kapasitesini al
            const availableClassrooms = await this.courseModel.sequelize.query(
              `SELECT c.name AS classroom, c.capacity 
               FROM classrooms c 
               WHERE c.capacity > (
                 SELECT DersiAlanKisiSayisi 
                 FROM courses 
                 WHERE code = :courseCode
               )`,
              { replacements: { courseCode: courseCode } }
            );

            // Eğer uygun derslik varsa, uygun saat ve derslik ile birlikte ekle
            if (availableClassrooms[0].length > 0) {
              availableClassrooms[0].forEach((classroom) => {
                availableSlots.push({
                  day: gun,
                  time: saat,
                  classroom: classroom.classroom, // Derslik ismi
                });
              });
            }
          }
        }
      }

      return availableSlots;
    } catch (error) {
      console.error("Hata:", error.message);
      throw error;
    }
  }
}

module.exports = ScheduleController;
