const { Sequelize, DataTypes } = require("sequelize");
const sequelize = require("../db/dbConnection");
const Joi = require("@hapi/joi");
const jwt = require("jsonwebtoken");

const User = sequelize.define(
  "User",
  {
    id: {
      type: DataTypes.INTEGER,
      autoIncrement: true,
      primaryKey: true,
    },
    isim: {
      type: DataTypes.STRING,
      allowNull: false,
      validate: {
        len: [3, 50],
      },
    },
    OgrenciNo: {
      type: DataTypes.STRING,
      allowNull: false,
      unique: true,
      validate: {
        len: [3, 50],
      },
    },
    sifre: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    bolum: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    sinif: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
  },
  {
    tableName: "users",
    timestamps: true,
  }
);

// Joi validation schema
const schema = Joi.object({
  isim: Joi.string().min(3).max(50).required(),
  OgrenciNo: Joi.string().min(3).max(50).required(),
  bolum: Joi.string().required(),
  sinif: Joi.number().integer().required(),
  sifre: Joi.string().required(),
});

// Instance method for Joi validation
User.prototype.joiValidation = function (userObject) {
  return schema.validate(userObject);
};

// Static method for Joi validation on update
User.joiValidationForUpdate = function (userObject) {
  return schema.validate(userObject);
};

// JWT token
User.prototype.generateToken = async function () {
  const user = this;
  const roles = await user.getRoles(); // Kullanıcının rollerini al
  const token = jwt.sign(
    { _id: user.id, roles: roles.map((role) => role.name) },
    "secretkey",
    { expiresIn: "2h" }
  );
  return token;
};

// 🔥 İlişkileri tanımlamayı en son yap
const Role = require("./roleModel");
const UserRole = require("./userRoleModel");

User.belongsToMany(Role, { through: UserRole, foreignKey: "userId" });
Role.belongsToMany(User, { through: UserRole, foreignKey: "roleId" });

module.exports = User;
