const { Sequelize, DataTypes } = require("sequelize");
const sequelize = require("../config/database"); // Veritabanı bağlantınızı buraya ekleyin

const Schedule = sequelize.define("Schedule", {
  // Birincil anahtar (id) alanı otomatik artırılır
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true,
    allowNull: false
  },
  
  // Department (Bölüm)
  department: {
    type: DataTypes.STRING(255),
    allowNull: false
  },
  
  // Grade (Ders yılı/sınıf)
  grade: {
    type: DataTypes.STRING(255),
    allowNull: false
  },
  
  // Day (Gün)
  day: {
    type: DataTypes.STRING(50),
    allowNull: false
  },
  
  // Time (Saat)
  time: {
    type: DataTypes.STRING(50),
    allowNull: false
  },
  
  // Course name (Ders adı)
  course_name: {
    type: DataTypes.STRING(255),
    allowNull: false
  },
  
  // Instructor (Öğretim görevlisi)
  instructor: {
    type: DataTypes.STRING(255),
    allowNull: false
  },
  
  // Classroom (Sınıf)
  classroom: {
    type: DataTypes.STRING(255),
    allowNull: false
  }
}, {
  // Tablo adı (Opsiyonel, varsayılan olarak model adının çoğul hali kullanılır)
  tableName: "schedules",
  
  // Tablonun otomatik olarak `createdAt` ve `updatedAt` tarihlerini takip etmesini istemiyorsanız
  timestamps: false
});

module.exports = Schedule;
