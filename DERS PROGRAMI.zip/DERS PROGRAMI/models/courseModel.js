const { DataTypes } = require("sequelize");
const sequelize = require("../db/dbConnection");

const Course = sequelize.define(
  "Course",
  {
    id: {
      type: DataTypes.INTEGER,
      autoIncrement: true,
      primaryKey: true,
    },
    name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    code: {
      type: DataTypes.STRING,
      allowNull: false,
      unique: true,
    },
    weekly_hours: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    instructor_name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    DersiHangiBolumAliyor: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    HangiSinif: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    AyniDersiAlanBolum: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    HangiIkincilSinif: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    DersOnlineMi: {
      type: DataTypes.TINYINT,
      allowNull: false,
    },
    DersiAlanKisiSayisi: {
      type: DataTypes.INTEGER,
      defaultValue: 0,
    },
  },
  {
    tableName: "courses",
    timestamps: false,
  }
);

module.exports = Course;
