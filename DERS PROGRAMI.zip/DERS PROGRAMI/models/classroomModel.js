const { DataTypes } = require('sequelize');
const sequelize = require('../db/dbConnection');

const Classroom = sequelize.define('Classroom', {
  id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },
  name: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  capacity: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },
  type: {
    type: DataTypes.ENUM('NORMAL', 'LAB'),
    allowNull: false,
  },
}, {
  tableName: 'classrooms',
  timestamps: false,
});

module.exports = Classroom;