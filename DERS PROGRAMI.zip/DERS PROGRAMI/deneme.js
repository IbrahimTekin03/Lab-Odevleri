const ExcelJS = require("exceljs");
const fs = require("fs");
const path = require("path");

const gunler = ["Pazartesi", "Salı", "Çarşamba", "Perşembe", "Cuma"];
const saatler = [
  "09:00-10:00",
  "10:00-11:00",
  "11:00-12:00",
  "13:00-14:00",
  "14:00-15:00",
  "15:00-16:00",
  "16:00-17:00",
];

const classrooms = [
  { id: 1, name: "M101", capacity: 66, type: "NORMAL" },
  { id: 2, name: "LAB1", capacity: 30, type: "LAB" },
];

const courses = [
  {
    id: 1,
    name: "Algoritmalar",
    code: "BLM101",
    weekly_hours: 3,
    instructor_name: "Dr. Ahmet",
    DersiHangiBolumAliyor: "BLM",
    HangiSinif: 1,
    AyniDersiAlanBolum: "YZM",
    HangiIkincilSinif: null,
    DersOnlineMi: false,
  },
];

const ogrenciSayilari = {
  "BLM-1": 60,
  "YZM-1": 55,
};

let program = {};
gunler.forEach((gun) => {
  program[gun] = {};
  saatler.forEach((saat) => {
    program[gun][saat] = {
      "1. Sınıf": null,
      "2. Sınıf": null,
      "3. Sınıf": null,
      "4. Sınıf": null,
    };
  });
});

function uygunSinifBul(kapasiteIhtiyaci, tip, gun, saat) {
  const kullanilan = Object.values(program[gun][saat]).map((x) => {
    if (!x) return null;
    const match = x.match(/- (.+)$/);
    return match ? match[1] : null;
  });

  return (
    classrooms.find(
      (sinif) =>
        sinif.type === tip &&
        sinif.capacity >= kapasiteIhtiyaci &&
        !kullanilan.includes(sinif.name)
    )?.name || null
  );
}

function slotMusaitMi(gun, saat, sinifKey, instructor) {
  if (program[gun][saat][sinifKey]) return false;
  return !Object.values(program[gun][saat]).some(
    (entry) => entry && entry.includes(instructor)
  );
}

function dersPrograminiOlustur() {
  let gunIndex = 0;
  courses.forEach((ders) => {
    let saatKalan = ders.weekly_hours;
    let sinifKey = `${ders.HangiSinif}. Sınıf`;
    const instructor = ders.instructor_name;
    const saatAraligi = ders.DersOnlineMi
      ? ["15:00-16:00", "16:00-17:00"]
      : saatler;
    const sinifTuru = ders.name.toLowerCase().includes("lab") ? "LAB" : "NORMAL";

    const bolumler = [ders.DersiHangiBolumAliyor].concat(
      (ders.AyniDersiAlanBolum || "")
        .split(",")
        .map((b) => b.trim())
        .filter((b) => b)
    );

    const ogrenciSayisi = bolumler.reduce((toplam, bolum) => {
      const key = `${bolum}-${ders.HangiSinif}`;
      return toplam + (ogrenciSayilari[key] || 0);
    }, 0);

    while (saatKalan > 0) {
      const gun = gunler[gunIndex % gunler.length];
      gunIndex++;
      for (let saat of saatAraligi) {
        if (slotMusaitMi(gun, saat, sinifKey, instructor)) {
          const sinifAdi = ders.DersOnlineMi
            ? "ONLINE"
            : uygunSinifBul(ogrenciSayisi, sinifTuru, gun, saat);
          if (!sinifAdi) continue;

          program[gun][saat][sinifKey] = `${ders.name} (${instructor}) - ${sinifAdi}`;
          saatKalan--;
          break;
        }
      }
    }
  });
}

async function dersPrograminiExcelYaz() {
  const templatePath = path.resolve(
    "c:/Users/ibrah/Downloads/BOŞ BÜTÜNLEŞİK ŞABLON - yazlab (1).xlsx"
  );
  const outputPath = path.resolve("generated_schedule.xlsx");

  const workbook = new ExcelJS.Workbook();
  await workbook.xlsx.readFile(templatePath);

  const worksheet = workbook.getWorksheet(1);

  const dayRows = {
    Pazartesi: 4,
    Salı: 14,
    Çarşamba: 23,
    Perşembe: 28,
    Cuma: 36,
  };

  const classColumns = {
    "1. Sınıf": "C",
    "2. Sınıf": "D",
    "3. Sınıf": "E",
    "4. Sınıf": "F",
  };

  gunler.forEach((gun) => {
    saatler.forEach((saat, index) => {
      Object.keys(program[gun][saat]).forEach((sinifKey) => {
        const dersBilgisi = program[gun][saat][sinifKey];
        if (dersBilgisi) {
          const row = dayRows[gun] + index;
          const col = classColumns[sinifKey];
          worksheet.getCell(`${col}${row}`).value = dersBilgisi;
        }
      });
    });
  });

  await workbook.xlsx.writeFile(outputPath);
  console.log(`Ders programı başarıyla oluşturuldu: ${outputPath}`);
}

dersPrograminiOlustur();
dersPrograminiExcelYaz();