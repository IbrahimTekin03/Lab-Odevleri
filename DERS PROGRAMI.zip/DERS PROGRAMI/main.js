const exp = require("constants");
const express = require("express");
const db = require("./db/dbConnection"); // MySQL bağlantısını yükledik
const hataMiddleware = require("./middleware/hataMiddleware");
const authMiddleware = require("./middleware/authMiddleware");
const passwordMiddleware = require("./middleware/passwordMiddleware");
const jwt = require("jsonwebtoken");
const cors = require("cors");
const courseRouter = require("./routers/courseRouter");
const departmentRouter = require("./routers/departmentRouter");
const classroomRouter = require("./routers/classroomRouter");
const bodyParser = require('body-parser');
const scheduleRouter = require('./routers/scheduleRouter');
const scheduleController = require('./controller/scheduleController');
const userRouter = require("./routers/userRouter");
const studentRouter = require("./routers/studentRouter");
const teacherRouter = require("./routers/teacherRouter");




// ROUTERS


const app = express();
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use(userRouter);
app.use(hataMiddleware);
app.use(courseRouter);
app.use(departmentRouter);
app.use(classroomRouter);
app.use(scheduleRouter);
app.use(studentRouter);
app.use("/teacher", teacherRouter);
app.use(scheduleRouter);

function test() {
  const token = jwt.sign(
    { _userID: "yenikullanicininidsi", email_active: false, isActive: false },
    "123456",
    { expiresIn: "2h" }
  );
  console.log(token);

  const sonuc = jwt.verify(token, "123456");
  console.log(sonuc);
}
test();

app.listen(3000, () => {
  console.log("3000 portu dinleniyor");
});