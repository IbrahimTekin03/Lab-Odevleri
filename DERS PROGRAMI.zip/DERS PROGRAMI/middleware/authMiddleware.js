const jwt = require("jsonwebtoken");
const User = require("../models/userModel");
const Role = require("../models/roleModel"); // Role modelini ekledik
const createError = require("http-errors");

const auth = async (req, res, next) => {
  try {
    const authHeader = req.header("Authorization");
    if (!authHeader) {
      throw createError(401, "Authorization başlığı eksik.");
    }

    const token = authHeader.replace("Bearer ", "");
    const decoded = jwt.verify(token, "secretkey");

    console.log("Authorization Header:", authHeader);
    console.log("Decoded Token:", decoded);

    const user = await User.findByPk(decoded._id, {
      include: [{ model: Role, through: { attributes: [] } }],
    });

    if (!user) {
      throw createError(401, "Kullanıcı bulunamadı");
    }

    req.user = {
      id: user.id,
      isim: user.isim,
      roles: user.Roles.map((role) => role.name),
    };

    next();
  } catch (error) {
    console.error("Yetkilendirme hatası:", error.message);
    next(createError(401, "Yetkilendirme başarısız."));
  }
};

module.exports = auth;
