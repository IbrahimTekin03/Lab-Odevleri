const bcrypt = require("bcrypt");
const createError = require("http-errors");
const User = require("../models/userModel");

const passwordMiddleware = async (req, res, next) => {
  const { OgrenciNo, sifre } = req.body;

  try {
    const user = await User.findOne({ where: { OgrenciNo } });

    if (!user) {
      throw createError(400, "Girilen Öğrenci No / şifre hatalı");
    }

    const sifreKontrol = await bcrypt.compare(sifre, user.sifre);
    if (!sifreKontrol) {
      throw createError(400, "Girilen Öğrenci No / şifre hatalı");
    }

    req.user = user;
    next();
  } catch (error) {
    next(error);
  }
};

module.exports = passwordMiddleware;